#include "OrderBook.hpp"

#include <cassert>
#include <iostream>

using quant::Order;
using quant::OrderBook;
using quant::Side;

int main() {
    OrderBook book;

    auto trades = book.submitLimit(Order{1, Side::Sell, 10100, 100, 1});
    assert(trades.empty());
    assert(book.liveOrderCount() == 1);

    trades = book.submitLimit(Order{2, Side::Sell, 10100, 50, 2});
    assert(trades.empty());
    assert(book.askLevels(1).front().quantity == 150);
    assert(book.askLevels(1).front().orderCount == 2);

    trades = book.submitLimit(Order{3, Side::Buy, 10100, 120, 3});
    assert(trades.size() == 2);
    assert(trades[0].restingId == 1);
    assert(trades[0].quantity == 100);
    assert(trades[1].restingId == 2);
    assert(trades[1].quantity == 20);
    assert(book.askLevels(1).front().quantity == 30);
    assert(book.liveOrderCount() == 1);

    trades = book.submitLimit(Order{4, Side::Buy, 10090, 10, 4});
    assert(trades.empty());
    assert(book.top().bestBid->priceTicks == 10090);

    assert(book.cancel(4));
    assert(!book.cancel(404));
    assert(!book.top().bestBid);
    assert(book.totalTradedQuantity() == 120);

    std::cout << "All order book tests passed.\n";
}
