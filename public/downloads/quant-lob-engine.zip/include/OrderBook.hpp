#pragma once

#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

namespace quant {

enum class Side {
    Buy,
    Sell,
};

struct Order {
    std::uint64_t id{};
    Side side{};
    std::int64_t priceTicks{};
    std::uint32_t quantity{};
    std::uint64_t timestamp{};
};

struct Trade {
    std::uint64_t aggressorId{};
    std::uint64_t restingId{};
    std::int64_t priceTicks{};
    std::uint32_t quantity{};
};

struct Level {
    std::int64_t priceTicks{};
    std::uint64_t quantity{};
    std::size_t orderCount{};
};

struct TopOfBook {
    std::optional<Level> bestBid;
    std::optional<Level> bestAsk;
};

class OrderBook {
public:
    std::vector<Trade> submitLimit(Order order);
    bool cancel(std::uint64_t orderId);

    TopOfBook top() const;
    std::vector<Level> bidLevels(std::size_t depth) const;
    std::vector<Level> askLevels(std::size_t depth) const;

    std::uint64_t totalTradedQuantity() const;
    std::size_t liveOrderCount() const;

private:
    using BidBook = std::map<std::int64_t, std::deque<Order>, std::greater<std::int64_t>>;
    using AskBook = std::map<std::int64_t, std::deque<Order>>;

    struct Locator {
        Side side{};
        std::int64_t priceTicks{};
    };

    static Level makeLevel(std::int64_t priceTicks, const std::deque<Order>& orders);
    static bool emptyOrZero(const Order& order);

    std::vector<Trade> matchBuy(Order& incoming);
    std::vector<Trade> matchSell(Order& incoming);
    void addResting(Order order);
    void eraseEmptyBestLevels();

    BidBook bids_;
    AskBook asks_;
    std::unordered_map<std::uint64_t, Locator> index_;
    std::uint64_t tradedQuantity_{};
};

std::string formatPrice(std::int64_t priceTicks);

}  // namespace quant
