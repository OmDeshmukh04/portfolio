#include "OrderBook.hpp"

#include <algorithm>
#include <iomanip>
#include <sstream>
#include <stdexcept>

namespace quant {

std::string formatPrice(std::int64_t priceTicks) {
    std::ostringstream out;
    out << (priceTicks / 100) << "." << std::setfill('0') << std::setw(2)
        << std::llabs(priceTicks % 100);
    return out.str();
}

std::vector<Trade> OrderBook::submitLimit(Order order) {
    if (emptyOrZero(order)) {
        throw std::invalid_argument("order id, price, and quantity must be positive");
    }
    if (index_.count(order.id) != 0) {
        throw std::invalid_argument("duplicate order id");
    }

    auto trades = (order.side == Side::Buy) ? matchBuy(order) : matchSell(order);

    if (order.quantity > 0) {
        addResting(order);
    }
    eraseEmptyBestLevels();
    return trades;
}

bool OrderBook::cancel(std::uint64_t orderId) {
    auto location = index_.find(orderId);
    if (location == index_.end()) {
        return false;
    }

    auto removeFromLevel = [orderId](auto& orders) {
        auto found = std::find_if(orders.begin(), orders.end(), [orderId](const Order& order) {
            return order.id == orderId;
        });
        if (found == orders.end()) {
            return false;
        }
        orders.erase(found);
        return true;
    };

    const auto side = location->second.side;
    const auto price = location->second.priceTicks;
    bool removed = false;

    if (side == Side::Buy) {
        auto level = bids_.find(price);
        removed = level != bids_.end() && removeFromLevel(level->second);
        if (level != bids_.end() && level->second.empty()) {
            bids_.erase(level);
        }
    } else {
        auto level = asks_.find(price);
        removed = level != asks_.end() && removeFromLevel(level->second);
        if (level != asks_.end() && level->second.empty()) {
            asks_.erase(level);
        }
    }

    index_.erase(location);
    return removed;
}

TopOfBook OrderBook::top() const {
    TopOfBook result;
    if (!bids_.empty()) {
        result.bestBid = makeLevel(bids_.begin()->first, bids_.begin()->second);
    }
    if (!asks_.empty()) {
        result.bestAsk = makeLevel(asks_.begin()->first, asks_.begin()->second);
    }
    return result;
}

std::vector<Level> OrderBook::bidLevels(std::size_t depth) const {
    std::vector<Level> levels;
    for (const auto& [price, orders] : bids_) {
        if (levels.size() == depth) {
            break;
        }
        levels.push_back(makeLevel(price, orders));
    }
    return levels;
}

std::vector<Level> OrderBook::askLevels(std::size_t depth) const {
    std::vector<Level> levels;
    for (const auto& [price, orders] : asks_) {
        if (levels.size() == depth) {
            break;
        }
        levels.push_back(makeLevel(price, orders));
    }
    return levels;
}

std::uint64_t OrderBook::totalTradedQuantity() const {
    return tradedQuantity_;
}

std::size_t OrderBook::liveOrderCount() const {
    return index_.size();
}

Level OrderBook::makeLevel(std::int64_t priceTicks, const std::deque<Order>& orders) {
    std::uint64_t quantity = 0;
    for (const auto& order : orders) {
        quantity += order.quantity;
    }
    return Level{priceTicks, quantity, orders.size()};
}

bool OrderBook::emptyOrZero(const Order& order) {
    return order.id == 0 || order.priceTicks <= 0 || order.quantity == 0;
}

std::vector<Trade> OrderBook::matchBuy(Order& incoming) {
    std::vector<Trade> trades;

    while (incoming.quantity > 0 && !asks_.empty()) {
        auto bestAsk = asks_.begin();
        if (bestAsk->first > incoming.priceTicks) {
            break;
        }

        auto& restingQueue = bestAsk->second;
        auto& resting = restingQueue.front();
        const auto traded = std::min(incoming.quantity, resting.quantity);

        trades.push_back(Trade{incoming.id, resting.id, resting.priceTicks, traded});
        incoming.quantity -= traded;
        resting.quantity -= traded;
        tradedQuantity_ += traded;

        if (resting.quantity == 0) {
            index_.erase(resting.id);
            restingQueue.pop_front();
        }
        if (restingQueue.empty()) {
            asks_.erase(bestAsk);
        }
    }

    return trades;
}

std::vector<Trade> OrderBook::matchSell(Order& incoming) {
    std::vector<Trade> trades;

    while (incoming.quantity > 0 && !bids_.empty()) {
        auto bestBid = bids_.begin();
        if (bestBid->first < incoming.priceTicks) {
            break;
        }

        auto& restingQueue = bestBid->second;
        auto& resting = restingQueue.front();
        const auto traded = std::min(incoming.quantity, resting.quantity);

        trades.push_back(Trade{incoming.id, resting.id, resting.priceTicks, traded});
        incoming.quantity -= traded;
        resting.quantity -= traded;
        tradedQuantity_ += traded;

        if (resting.quantity == 0) {
            index_.erase(resting.id);
            restingQueue.pop_front();
        }
        if (restingQueue.empty()) {
            bids_.erase(bestBid);
        }
    }

    return trades;
}

void OrderBook::addResting(Order order) {
    auto& book = order.side == Side::Buy ? bids_[order.priceTicks] : asks_[order.priceTicks];
    index_[order.id] = Locator{order.side, order.priceTicks};
    book.push_back(order);
}

void OrderBook::eraseEmptyBestLevels() {
    while (!bids_.empty() && bids_.begin()->second.empty()) {
        bids_.erase(bids_.begin());
    }
    while (!asks_.empty() && asks_.begin()->second.empty()) {
        asks_.erase(asks_.begin());
    }
}

}  // namespace quant
