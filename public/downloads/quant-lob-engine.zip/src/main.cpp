#include "OrderBook.hpp"

#include <iostream>

using quant::Order;
using quant::OrderBook;
using quant::Side;

namespace {

void printTrades(const std::vector<quant::Trade>& trades) {
    for (const auto& trade : trades) {
        std::cout << "TRADE aggressor=" << trade.aggressorId
                  << " resting=" << trade.restingId
                  << " price=" << quant::formatPrice(trade.priceTicks)
                  << " qty=" << trade.quantity << '\n';
    }
}

void printTop(const OrderBook& book) {
    const auto top = book.top();
    std::cout << "TOP ";
    if (top.bestBid) {
        std::cout << "bid=" << quant::formatPrice(top.bestBid->priceTicks)
                  << "x" << top.bestBid->quantity << " ";
    } else {
        std::cout << "bid=NA ";
    }
    if (top.bestAsk) {
        std::cout << "ask=" << quant::formatPrice(top.bestAsk->priceTicks)
                  << "x" << top.bestAsk->quantity;
    } else {
        std::cout << "ask=NA";
    }
    std::cout << '\n';
}

}  // namespace

int main() {
    OrderBook book;
    std::uint64_t ts = 1;

    printTrades(book.submitLimit(Order{1, Side::Sell, 10125, 80, ts++}));
    printTrades(book.submitLimit(Order{2, Side::Sell, 10130, 40, ts++}));
    printTrades(book.submitLimit(Order{3, Side::Buy, 10100, 50, ts++}));
    printTop(book);

    printTrades(book.submitLimit(Order{4, Side::Buy, 10130, 100, ts++}));
    printTop(book);

    std::cout << "cancel id=3 -> " << (book.cancel(3) ? "true" : "false") << '\n';
    printTop(book);
    std::cout << "live_orders=" << book.liveOrderCount()
              << " traded_qty=" << book.totalTradedQuantity() << '\n';
}
