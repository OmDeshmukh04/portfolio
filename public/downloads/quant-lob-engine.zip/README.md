# C++ Limit Order Book and Matching Engine

A compact C++17 limit order book built for quant developer interview preparation. It models price-time priority, deterministic matching, cancellation, and top-of-book snapshots.

## Why this project matters

Quant developer and HFT interviews often test whether a candidate can reason about market microstructure and write careful systems code. This project gives concrete talking points around:

- Price-time priority
- Bid/ask crossing logic
- Partial fills
- Resting order queues
- Order cancellation
- Deterministic test cases
- Integer price representation to avoid floating-point money errors

## Build

```powershell
cmake -S . -B build
cmake --build build
```

If CMake is not available:

```powershell
g++ -std=c++17 -O2 -I include src/OrderBook.cpp src/main.cpp -o lob_demo
g++ -std=c++17 -O2 -I include src/OrderBook.cpp tests/basic_test.cpp -o lob_tests
```

## Run

```powershell
.\build\lob_demo.exe
.\build\lob_tests.exe
```

## Resume bullet

Built a C++17 limit order book and matching engine with price-time priority, partial-fill handling, order cancellation, integer tick pricing, and deterministic tests for bid/ask crossing and book state validation.
